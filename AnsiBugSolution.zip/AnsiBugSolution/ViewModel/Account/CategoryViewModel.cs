﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections.ObjectModel;
using Model.Account;
using DAL.Account;
using System.ComponentModel;

namespace ViewModel.Account
{
    public class CategoryViewModel
    {
        //private Category _selectedCategory;
        //public MyICommand DeleteCommand { get; set; }
        //public Category SelectedCategory
        //{
        //    get
        //    {
        //        return _selectedCategory;
        //    }

        //    set
        //    {
        //        _selectedCategory = value;
        //        DeleteCommand.RaiseCanExecuteChanged();
        //    }
        //}

        public CategoryViewModel()
        {
            LoadCategories();
            //DeleteCommand = new MyICommand(OnDelete, CanDelete);
        }

        public List<Category> Categories_GetAll { get; set; }

        public void LoadCategories()
        {
            DalCategory dalCategory = new DalCategory();
            Categories_GetAll = new List<Category>();
            var categories = dalCategory.GetCategories();

            if (categories != null)
            {
                Categories_GetAll = categories;
            }
        }

        #region Delete
        //private void OnDelete()
        //{
        //    Categories_GetAll.Remove(SelectedCategory);
        //}

        //private bool CanDelete()
        //{
        //    return SelectedCategory != null;
        //}
        #endregion       
    }
}
