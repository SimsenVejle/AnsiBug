﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using Model.Account;
using System.ComponentModel;
using Dapper;
using System.Linq;
using System.Collections.ObjectModel;
using System.Configuration;
using DAL;
using System.Data.SqlClient;

namespace DAL.Account
{
    public class DalCategory
    {
        #region Get
        public List<Category> GetCategories()
        {
            string cnn = ConfigurationManager.ConnectionStrings["AnsiBugDb"].ConnectionString;
            using (IDbConnection connection = new SqlConnection(cnn))
            {
                if (connection.State == ConnectionState.Closed)
                {
                    connection.Open();
                }

                return connection.Query<Category>("dbo.Category_GetAll").ToList();
            }
        }
        #endregion

        #region Insert
        #endregion

        #region Update
        #endregion

        #region Delete
        #endregion
    }
}
