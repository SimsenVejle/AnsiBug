﻿using Microsoft.Extensions.Configuration;
using System.IO;
using System.Configuration;
using System.Data.SqlClient;
using System;

namespace DAL
{
    public class Helper
    {
        private static readonly string db = "AnsiBugDb";

        public static string Conn()
        {
            return ConfigurationManager.ConnectionStrings[db].ConnectionString;
        }
    }
}
