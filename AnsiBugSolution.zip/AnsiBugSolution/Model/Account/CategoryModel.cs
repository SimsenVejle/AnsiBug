﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace Model.Account
{
    public class CategoryModel { }

    public class Category : INotifyPropertyChanged
    {
        private int categoryId;

        public int CategoryId
        {
            get
            {
                return categoryId;
            }

            set
            {
                if (categoryId != value)
                {
                    categoryId = value;
                }
            }
        }

        private string categoryName;

        public string CategoryName
        {
            get { return categoryName; }
            set
            {
                if (categoryName != value)
                {
                    categoryName = value;
                    RaisePropertyChanged("CategoryName");
                }
            }
        }

        private bool categoryIsGlobal;

        public bool CategoryIsGlobal
        {
            get { return categoryIsGlobal; }
            set
            {
                if (categoryIsGlobal != value)
                {
                    categoryIsGlobal = value;
                    RaisePropertyChanged("CategoryIsGlobal");
                }
            }
        }

        private bool isObsolete;

        public bool IsObsolete
        {
            get { return isObsolete; }
            set { isObsolete = value; }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        private void RaisePropertyChanged(string property)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(property));
        }
    }
}
