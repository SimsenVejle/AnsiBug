﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using Model.Account;
using System.ComponentModel;
using Dapper;
using System.Linq;
using System.Collections.ObjectModel;
using System.Configuration;
using System.Data.SqlClient;

namespace DAL.Account
{
    public class DalCategory
    {
        #region Get
        public List<Category> GetCategories()
        {
            string cnn = ConfigurationManager.ConnectionStrings["AnsiBugDb"].ToString();
            if (cnn != string.Empty)
            {
                using (IDbConnection connection = new SqlConnection(cnn))
                {
                    if (connection.State == ConnectionState.Closed)
                    {
                        connection.Open();
                    }

                    List<Category> testList = connection.Query<Category>("dbo.Category_GetAll").ToList();

                    return testList;
                }
            }
            else
            {
                return new List<Category>();
            }
            //TODO Try/Catch
            //try
            //{
            //    string cnn = ConfigurationManager.ConnectionStrings["AnsiBugDb"].ToString();
            //    if (cnn != string.Empty)
            //    {
            //        using (IDbConnection connection = new SqlConnection(cnn))
            //        {
            //            if (connection.State == ConnectionState.Closed)
            //            {
            //                connection.Open();
            //            }

            //            return connection.Query<Category>("dbo.Category_GetAll").ToList();
            //        }
            //    }
            //    else
            //    {
            //        return new List<Category>();
            //    }
            //}
            //catch (SqlException ex)
            //{
            //    Helper helper = new Helper();
            //    helper.ErrorMessagesSqlException(ex);

            //    return new List<Category>();
            //}
            //catch (Exception ex)
            //{
            //    Helper helper = new Helper();
            //    helper.ErrorMessagesException(ex);

            //    return new List<Category>();
            //}
        }
        #endregion

        #region Insert
        public int NewCategory(Category objCat)
        {
            string cnn = ConfigurationManager.ConnectionStrings["AnsiBugDb"].ToString();
            if (cnn != string.Empty)
            {
                using (IDbConnection connection = new SqlConnection(cnn))
                {
                    if (connection.State == ConnectionState.Closed)
                    {
                        connection.Open();
                    }

                    var param = new DynamicParameters();
                    param.Add("@CategoryName", dbType: DbType.String, value: objCat.CategoryName);
                    param.Add("@CategoryIsGlobal", dbType: DbType.Boolean, value: objCat.CategoryIsGlobal);
                    param.Add("@CategoryIsObsolete", dbType: DbType.Boolean, value: objCat.CategoryIsObsolete);
                    param.Add("@ProjectId", dbType: DbType.Int32, value: objCat.ProjectId);
                    param.Add("@Id", dbType: DbType.String, direction:ParameterDirection.Output, size:5215585);

                    connection.Execute("Category_New", param, commandType: CommandType.StoredProcedure);

                    var Id = param.Get<string>("@Id");
                    
                    return Convert.ToInt32(Id);
                }
            }
            else
            {
                return 0;
            }
            //TODO Try/Catch            
        }
        #endregion

        #region Update
        public void SetCategory(Category objCat)
        {
            string cnn = ConfigurationManager.ConnectionStrings["AnsiBugDb"].ToString();
            if (cnn != string.Empty)
            {
                using (IDbConnection connection = new SqlConnection(cnn))
                {
                    if (connection.State == ConnectionState.Closed)
                    {
                        connection.Open();
                    }

                    connection.Execute("Category_Set", objCat, commandType: CommandType.StoredProcedure);
                }
            }
            //TODO Try/Catch            
        }
        #endregion

        #region Delete
        #endregion
    }
}
