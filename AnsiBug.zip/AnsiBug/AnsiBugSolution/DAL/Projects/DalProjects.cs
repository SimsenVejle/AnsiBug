﻿using System.Data;
using Dapper;
using System.Linq;
using System.Collections.ObjectModel;
using System.Configuration;
using Model.Projects;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace DAL.Projects
{
    public class DalProjects
    {
        #region Get
        public List<Project> GetProjects()
        {
            string cnn = ConfigurationManager.ConnectionStrings["AnsiBugDb"].ToString();
            if (cnn != string.Empty)
            {
                using (IDbConnection connection = new SqlConnection(cnn))
                {
                    if (connection.State == ConnectionState.Closed)
                    {
                        connection.Open();
                    }

                    return connection.Query<Project>("dbo.Project_GetAll").ToList();
                }
            }
            else
            {
                return new List<Project>();
            }
            //TODO Try/Catch            
        }
        #endregion

        #region Insert
        #endregion

        #region Update
        #endregion

        #region Delete
        #endregion
    }
}
