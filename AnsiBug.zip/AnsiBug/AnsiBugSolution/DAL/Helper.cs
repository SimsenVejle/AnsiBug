﻿using Microsoft.Extensions.Configuration;
using System.IO;
using System.Configuration;
using System.Data.SqlClient;
using System;
using System.Text;
using System.Net;
using System.Net.Mail;

namespace DAL
{
    public class Helper
    {
        #region Exception handling
        // Try/Catch error message builder        
        public void ErrorMessagesSqlException(SqlException ex)
        {
            StringBuilder errorMessages = new StringBuilder();
            for (int i = 0; i < ex.Errors.Count; i++)
            {
                errorMessages.Append("Date" + DateTime.Now + "\n" +
                    "Index #" + i + "\n" +
                    "Message: " + ex.Errors[i].Message + "\n" +
                    "LineNumber: " + ex.Errors[i].LineNumber + "\n" +
                    "Source: " + ex.Errors[i].Source + "\n" +
                    "Procedure: " + ex.Errors[i].Procedure + "\n" + "\n" + "\n");
            }


            //Fejl rapporteringer til email og fil
            bool isSendEmailByError = Convert.ToBoolean((ConfigurationManager.AppSettings["SendEmailByError".ToString()]));

            if (isSendEmailByError)
                SendEmailByErrors("SqlException", errorMessages.ToString());

            SendErrorMessagesToFile(errorMessages.ToString());
        }

        public void ErrorMessagesException(Exception ex)
        {
            StringBuilder errorMessages = new StringBuilder();
            errorMessages.Append("Date" + DateTime.Now + "\n" +
                "Index #" + "\n" +
                "Message: " + ex.Message + "\n" +
                "Source: " + ex.Source + "\n" + "\n" + "\n");


            //Fejl rapporteringer til email og fil
            bool isSendEmailByError = Convert.ToBoolean((ConfigurationManager.AppSettings["SendEmailByError".ToString()]));

            if (isSendEmailByError)
                SendEmailByErrors("Exception", errorMessages.ToString());

            SendErrorMessagesToFile(errorMessages.ToString());
        }

        //Save error messages to file
        public void SendErrorMessagesToFile(string errorMessages)
        {
            try
            {
                string path = (ConfigurationManager.AppSettings["ErrorFileMessagePath".ToString()]);

                if (!File.Exists(path))
                {
                    //Create file
                    StreamWriter sw = File.CreateText(path);
                    using (sw)
                    {
                        sw.WriteLine(errorMessages);
                    }
                }
                else
                {
                    //Text added to file
                    StreamWriter streamWriter = File.AppendText(path);
                    using (streamWriter)
                    {
                        streamWriter.WriteLine(errorMessages);
                    }
                }                
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        //Send email to admin by errors
        public void SendEmailByErrors(string ExceptionName, string ErrorMessage)
        {
            var fromAddress = new MailAddress(ConfigurationManager.AppSettings["EmailFrom".ToString()], ConfigurationManager.AppSettings["EmailFromName".ToString()]);
            var toAddress = new MailAddress(ConfigurationManager.AppSettings["EmailTo".ToString()], ConfigurationManager.AppSettings["EmailToName".ToString()]);
            string fromPassword = ConfigurationManager.AppSettings["EmailFromPassword".ToString()];
            string subject = ExceptionName;
            string body = ErrorMessage;            

            var smtp = new SmtpClient
            {
                Host = "smtp.gmail.com",
                Port = 587,
                EnableSsl = true,
                DeliveryMethod = SmtpDeliveryMethod.Network,
                UseDefaultCredentials = false,
                Credentials = new NetworkCredential(fromAddress.Address, fromPassword)
            };

            using (var message = new MailMessage(fromAddress, toAddress)
            {
                Subject = subject,
                Body = body
            })
            {
                smtp.Send(message);
            }
        }
        #endregion
    }
}
