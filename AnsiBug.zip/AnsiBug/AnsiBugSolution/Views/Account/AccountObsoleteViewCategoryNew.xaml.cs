﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Views.Account
{
    /// <summary>
    /// Interaction logic for AccountObsoleteViewCategoryNew.xaml
    /// </summary>
    public partial class AccountObsoleteViewCategoryNew : UserControl
    {
        public AccountObsoleteViewCategoryNew()
        {
            InitializeComponent();
            DataContext = new ViewModel.Account.CategoryViewModel();
        }

        //public object Ressource { get; private set; }

        private void BtnNewCancel_Click(object sender, RoutedEventArgs e)
        {
            ClearFields();

            var myWindow = Window.GetWindow(this);
            myWindow.Close();
        }

        private void ClearFields()
        {
            TxtCategoryActiveNameNew.Text = string.Empty;
            CbxCategoryActiveGlobalNew.IsChecked = false;
            CbxCategoryActiveActiveNew.IsChecked = false;
            CbxProjectCategoryActiveNew.SelectedIndex = 0;
        }
    }
}
