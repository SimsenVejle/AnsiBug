﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace Model.Account
{
    public class CategoryModel { }

    public class Category : INotifyPropertyChanged
    {
        public Category(){}

        private int categoryId;
        public int CategoryId
        {
            get { return categoryId; }
            set { categoryId = value; OnPropertyChanged("CategoryId"); }
        }

        private string categoryName;
        public string CategoryName
        {
            get { return categoryName; }
            set { categoryName = value; OnPropertyChanged("CategoryName"); }
        }

        private bool categoryIsGlobal;
        public bool CategoryIsGlobal
        {
            get { return categoryIsGlobal; }
            set { categoryIsGlobal = value; OnPropertyChanged("CategoryIsGlobal"); }
        }

        private bool categoryIsObsolete;
        public bool CategoryIsObsolete
        {
            get { return categoryIsObsolete; }
            set { categoryIsObsolete = value; OnPropertyChanged("CategoryIsObsolete"); }
        }

        private int projectId;
        public int ProjectId
        {
            get { return projectId; }
            set { projectId = value; OnPropertyChanged("ProjectId"); }
        }

        private string projectName;
        public string ProjectName
        {
            get { return projectName; }
            set { projectName = value; OnPropertyChanged("ProjectName"); }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        private void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
