﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace Model.Projects
{
    public class ProjectModels { }
    public class Project : INotifyPropertyChanged
    {
        public Project() { }

        private int projectId;

        public int ProjectId
        {
            get { return projectId; }
            set { projectId = value; OnPropertyChanged("ProjectId"); }
        }

        private string projectName;

        public string ProjectName
        {
            get { return projectName; }
            set { projectName = value; OnPropertyChanged("ProjectName"); }
        }

        private string projectDescription;

        public string ProjectDescription
        {
            get { return projectDescription; }
            set { projectDescription = value; OnPropertyChanged("ProjectDescription"); }
        }

        private bool projectIsActive;

        public bool ProjectIsActive
        {
            get { return projectIsActive; }
            set { projectIsActive = value; OnPropertyChanged("ProjectIsActive"); }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        private void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
