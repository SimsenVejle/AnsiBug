﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Windows.Input;

namespace ViewModel.Account
{
    public class TestViewModel : INotifyPropertyChanged
    {
        public TestViewModel()
        {
            //LoadCategories();
            //LoadProjects();
            //CmdSave = new MyICommand(SaveChanges);
            CmdSaveNew = new MyICommand(SaveChangesNew);
        }

        private string _messageError;
        public string MessageError
        {
            get => _messageError;
            set
            {
                _messageError = value;
                OnPropertyChanged("MessageError");
            }
        }

        public MyICommand CmdSaveNew { get; set; }
        public void SaveChangesNew()
        {
            MessageError = "This message I want to see in the view";
        }

        #region INotifyPropertyChanged Members
        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged(string propertyName) =>
          PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        #endregion
    }
}
