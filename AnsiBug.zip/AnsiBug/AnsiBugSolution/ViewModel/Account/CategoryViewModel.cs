﻿using System.Collections.Generic;
using Model.Account;
using DAL.Account;
using System.Linq;
using Model.Projects;
using DAL.Projects;
using System.ComponentModel;
using System.Windows.Input;
using System.Windows;
using System;
using System.Collections.ObjectModel;

namespace ViewModel.Account
{
    public class CategoryViewModel : INotifyPropertyChanged
    {
        public CategoryViewModel()
        {
            LoadCategories();
            LoadProjects();
            CmdSave = new MyICommand(SaveChanges);
            CmdSaveNew = new MyICommand(SaveNew);
        }

        #region Messages
        private string _messageError;
        public string MessageError
        {
            get => _messageError;
            set
            {
                _messageError = value;
                OnPropertyChanged("MessageError");
            }
        }

        private string _messageOk;
        public string MessageOk
        {
            get => _messageOk;
            set
            {
                _messageOk = value;
                OnPropertyChanged("MessageOk");
            }
        }
        #endregion

        #region New

        public string CategoryName { get; set; }
        public bool CategoryIsGlobal { get; set; }
        public bool CategoryIsObsolete { get; set; }
        public int ProjectId { get; set; }

        #endregion

        #region Get
        //Categories
        //All
        private ObservableCollection<Category> _categories_GetAll;
        public ObservableCollection<Category> Categories_GetAll 
        { 
            get
            {
                return _categories_GetAll;
            }
            set
            {
                _categories_GetAll = value;
                OnPropertyChanged("Categories_GetAll");
            }
        }

        //Active
        private ObservableCollection<Category> _categories_GetActive;
        public ObservableCollection<Category> Categories_GetActive
        {
            get
            {
                return _categories_GetActive;
            }
            set
            {
                _categories_GetActive = value;
                OnPropertyChanged("Categories_GetActive");
            }
        }

        //Inactive
        private ObservableCollection<Category> _categories_GetInactive;
        public ObservableCollection<Category> Categories_GetInactive
        { 
            get
            {
                return _categories_GetInactive;
            }
            set
            {
                _categories_GetInactive = value;
                OnPropertyChanged("Categories_GetInactive");
            }
        }

        //Load Categories
        public void LoadCategories()
        {
            DalCategory dalCategory = new DalCategory();
            var categories = dalCategory.GetCategories();

            if (categories != null)
            {
                //All
                List<Category> Categories_GetAllList = categories;
                Categories_GetAll = new ObservableCollection<Category>(Categories_GetAllList);

                //Active
                List<Category> Categories_GetActiveList = categories.Where(x => x.CategoryIsObsolete == false).ToList();
                Categories_GetActive = new ObservableCollection<Category>(Categories_GetActiveList);

                //Inactive
                List<Category> Categories_GetInactiveList = categories.Where(x => x.CategoryIsObsolete == true).ToList();
                Categories_GetInactive = new ObservableCollection<Category>(Categories_GetInactiveList);
            }
        }

        //Projects
        public List<Project> Projects_GetActive { get; set; }
        public void LoadProjects()
        {
            DalProjects dalProjects = new DalProjects();
            var projects = dalProjects.GetProjects();

            if (projects != null)
            {
                //Active
                Projects_GetActive = projects.Where(x => x.ProjectIsActive == true).ToList();
            }
        }
        #endregion

        #region Set
        public MyICommand CmdSave { get; set; }
        public void SaveChanges()
        {
            ResetMessages();
            if (SelectedCategory != null)
            {

            }
        }

        public MyICommand CmdSaveNew { get; set; }

        public void SaveNew()
        {
            ResetMessages();

            DalCategory dal = new DalCategory();


            CategoryName = "test 1";
            if (!string.IsNullOrEmpty(CategoryName))
            {
                string name = CategoryName;
                bool global = CategoryIsGlobal;
                bool obsolete = CategoryIsObsolete;
                int projectId = ProjectId;

                Category cat = new Category();
                //cat.CategoryName = CategoryName;
                //cat.CategoryIsGlobal = CategoryIsGlobal;
                //cat.CategoryIsObsolete = CategoryIsObsolete;
                //cat.ProjectId = ProjectId;
                cat.CategoryName = "test 1";
                cat.CategoryIsGlobal = true;
                cat.CategoryIsObsolete = false;
                cat.ProjectId = 1;

                int categoryId = dal.NewCategory(cat);

                cat.CategoryId = categoryId;

                if (cat.CategoryIsObsolete == false)
                {
                    Categories_GetAll.Add(cat);
                    Categories_GetActive.Add(cat);                    
                }
                else
                {
                    Categories_GetInactive.Add(cat);
                }

                MessageOk = "Kategorien er gemt";
            }
            else
            {
                MessageError = "Kategorinavn skal udfyldes";
            }
        }
        #endregion

        #region Delete        
        #endregion

        #region Helpers
        public void ResetMessages()
        {
            MessageError = string.Empty;
            MessageOk = string.Empty;
        }
        #endregion

        #region SelectedItem
        private Category _selectedCategory;

        public Category SelectedCategory
        {
            get
            {
                return _selectedCategory;
            }

            set
            {
                _selectedCategory = value;
                OnPropertyChanged("SelectedCategory");
            }
        }
        #endregion

        #region INotifyPropertyChanged Members
        public event PropertyChangedEventHandler PropertyChanged;

        public void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
        #endregion
    }
}
