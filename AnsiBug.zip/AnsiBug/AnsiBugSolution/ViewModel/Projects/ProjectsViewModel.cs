﻿using System.Collections.Generic;
using DAL.Account;
using System.Linq;
using Model.Projects;
using DAL.Projects;

namespace ViewModel.Projects
{
    public class ProjectsViewModel
    {
        private Project _selectedProject;
        public MyICommand DeleteCommand { get; set; }

        public Project SelectedProject
        {
            get
            {
                return _selectedProject;
            }

            set
            {
                _selectedProject = value;
                DeleteCommand.RaiseCanExecuteChanged();
            }
        }

        public ProjectsViewModel()
        {
            LoadProjects();
            DeleteCommand = new MyICommand(OnDelete, CanDelete);
        }

        public List<Project> Projects_GetAll { get; set; }
        public List<Project> Projects_GetActive { get; set; }
        public List<Project> Projects_GetInactive { get; set; }

        public void LoadProjects()
        {
            DalProjects dalProject = new DalProjects();
            var projects = dalProject.GetProjects();

            if (projects != null)
            {
                //All
                Projects_GetAll = projects;

                //Active
                Projects_GetActive = projects.Where(x => x.ProjectIsActive == true).ToList();

                //Inactive
                Projects_GetInactive = projects.Where(x => x.ProjectIsActive == false).ToList();
            }
        }


        public void SaveChanges()
        {
            //Her gemmes ændringer
            //CategoryModel mod = new CategoryModel();
            ///Debug.Assert(false, String.Format("{0} was updated", cat.CategoryName));
        }
        #region Delete

        private void OnDelete()
        {
            //Category cat = SelectedCategory;
            //int id = cat.CategoryId;
            //Categories_GetActive.Remove(SelectedCategory);
        }

        private bool CanDelete()
        {
            return SelectedProject != null;
        }
        #endregion
    }
}
