﻿using System;
using System.Collections.Generic;
using System.Data;
using Model.Account;
using System.ComponentModel;
using Dapper;
using System.Linq;
using System.Configuration;
using System.Data.SqlClient;

namespace DAL.Account
{
    public class DalCategory
    {
        #region Get
        public List<Category> GetCategories()
        {
            string cnn = ConfigurationManager.ConnectionStrings["AnsiBugDb"].ToString();
            if (cnn != string.Empty)
            {
                using (IDbConnection connection = new SqlConnection(cnn))
                {
                    if (connection.State == ConnectionState.Closed)
                    {
                        connection.Open();
                    }

                    return connection.Query<Category>("dbo.Category_GetAll").ToList();
                }
            }
            else
            {
                return new List<Category>();
            }
            //TODO Try/Catch
            //try
            //{
            //    string cnn = ConfigurationManager.ConnectionStrings["AnsiBugDb"].ToString();
            //    if (cnn != string.Empty)
            //    {
            //        using (IDbConnection connection = new SqlConnection(cnn))
            //        {
            //            if (connection.State == ConnectionState.Closed)
            //            {
            //                connection.Open();
            //            }

            //            return connection.Query<Category>("dbo.Category_GetAll").ToList();
            //        }
            //    }
            //    else
            //    {
            //        return new List<Category>();
            //    }
            //}
            //catch (SqlException ex)
            //{
            //    Helper helper = new Helper();
            //    helper.ErrorMessagesSqlException(ex);

            //    return new List<Category>();
            //}
            //catch (Exception ex)
            //{
            //    Helper helper = new Helper();
            //    helper.ErrorMessagesException(ex);

            //    return new List<Category>();
            //}
        }
        #endregion

        #region Insert
        #endregion

        #region Update
        #endregion

        #region Delete
        #endregion
    }
}
